public interface Enrollment {
    void enrollStudentInCourse(Student student, Course course);
}